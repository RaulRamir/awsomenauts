	
<?php

	require_once(__DIR__ . "/view/header.php");//requires the header at the top of the page
	require_once(__DIR__ . "/view/form.php");//requires the form file
	require_once(__DIR__ . "/view/footer.php");//requires the footer

 ?>
 


 
 
 