<?php
	require_once(__DIR__ . "/view/header.php");
	require_once(__DIR__ . "/view/register-form.php");
	require_once(__DIR__ . "/view/footer.php");







