<section class="right">
<article>
		<img width="200" height="200" align="right"src="http://www.laboiteverte.fr/wp-content/uploads/2014/03/gif-hypnotique-024.gif">
</article>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="js/readmore.min.js"></script>
</section>

 <script>
  $('.post').readmore({
    maxHeight: 100
  });
  </script>
</body>
</html>
